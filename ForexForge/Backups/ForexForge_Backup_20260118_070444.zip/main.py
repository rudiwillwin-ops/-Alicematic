# main.py (The 24/7 Execution Engine)

import MetaTrader5 as mt5
import os
import time
import datetime
import zipfile
import logging
from config import MT5_LOGIN, MT5_PASSWORD, MT5_SERVER, SYMBOL_SUFFIX, RISK_PER_TRADE, MAX_DAILY_LOSS, ZAR_RED_FLAGS

# --- Setup Logging ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s',
                    handlers=[logging.FileHandler("forex_forge.log"), logging.StreamHandler()])

def backup_project():
    """Zips main.py and config.py into a /Backups/ folder."""
    try:
        if not os.path.exists('Backups'):
            os.makedirs('Backups')
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = f"Backups/ForexForge_Backup_{timestamp}.zip"
        
        with zipfile.ZipFile(backup_filename, 'w') as zf:
            zf.write('main.py')
            zf.write('config.py')
        logging.info(f"Project backed up to {backup_filename}")
    except Exception as e:
        logging.error(f"Error during project backup: {e}")

def get_pip_value(symbol, lot_size):
    """
    Calculate the value of a single pip for a given symbol and lot size.
    Note: This is a simplified calculation. A more precise calculation would
    involve the account currency and the current exchange rate.
    """
    symbol_info = mt5.symbol_info(symbol)
    if symbol_info is None:
        logging.error(f"Could not get symbol info for {symbol}")
        return 0

    if "JPY" in symbol.upper():
        pip_value = 0.01
    else:
        pip_value = 0.0001
        
    # For a micro lot (1,000 units), assuming USD account
    # This needs to be adjusted based on the quote currency of the pair
    # and the account currency.
    # For now, we use a rough estimation.
    tick_value = symbol_info.trade_tick_value
    point = symbol_info.point
    
    # A more reliable way if tick value is correctly provided by the broker
    if tick_value != 0 and point != 0:
         return (pip_value / point) * tick_value * lot_size
    else: # Fallback to a rough estimation
        # This is a very rough estimation and might not be accurate
        if "USD" in symbol_info.currency_profit:
            return lot_size * 1000 * pip_value
        else:
            # Fallback for non-USD pairs - this is a placeholder
            # In a real scenario, you'd need a currency conversion rate.
            return lot_size * 1000 * pip_value 


def calculate_lot_size(balance, stop_loss_pips, symbol):
    """Calculates the lot size based on risk percentage."""
    if stop_loss_pips <= 0:
        return 0.01 # Default minimum lot size

    # A simplified approach to pip value, assuming a micro account
    # A proper implementation would need to get the exact pip value for the pair
    # from the broker or calculate it based on the currency.
    # We will use a placeholder function for now.
    pip_value_per_lot = get_pip_value(symbol, 1.0)
    
    if pip_value_per_lot == 0:
        logging.warning("Pip value is zero, using default lot size.")
        return 0.01

    risk_amount = balance * RISK_PER_TRADE
    lot_size = risk_amount / (stop_loss_pips * pip_value_per_lot)

    # Normalize lot size to broker's allowed volume steps
    symbol_info = mt5.symbol_info(symbol)
    if symbol_info:
        min_lot = symbol_info.volume_min
        max_lot = symbol_info.volume_max
        lot_step = symbol_info.volume_step
        
        lot_size = max(min_lot, round(lot_size / lot_step) * lot_step)
        lot_size = min(max_lot, lot_size)

    return round(lot_size, 2) if lot_size > 0 else 0.01


def news_scanner():
    """
    Scans for South African news and returns True if trading should be paused.
    This is a dummy function. A real implementation would use a news API or web scraping.
    """
    logging.info("Scanning for high-impact South African news...")
    # This is a placeholder. In a real application, you would use a library
    # like investpy or beautifulsoup to scrape news from a financial website.
    # For now, it simulates finding red flags.
    
    # --- SIMULATED NEWS SCAN ---
    # import random
    # found_flags = random.sample(ZAR_RED_FLAGS, random.randint(0, 5)) 
    found_flags = [] # No flags found in this simulation
    
    logging.info(f"Found news flags: {found_flags}")
    if len(found_flags) >= 3:
        logging.warning(f"High volatility expected. Pausing ZAR trading for 24 hours.")
        return True
    return False

def smc_strategy(symbol):
    """
    Simplified Smart Money Concepts (SMC) strategy implementation.
    This is a conceptual outline. Real SMC trading requires sophisticated analysis.
    """
    logging.info(f"Analyzing {symbol} using SMC strategy...")
    
    # 1. The Trap: Monitor for Liquidity Sweeps
    # Get previous session high/low (e.g., Asia session for London open)
    # This is a placeholder logic
    rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M1, 0, 100)
    if rates is None or len(rates) < 100:
        logging.warning("Not enough data for SMC analysis.")
        return None, None, None

    # Placeholder for session high/low
    prev_session_high = max(rates['high'])
    prev_session_low = min(rates['low'])

    # 2. The Shift: Detect CHoCH (Change of Character)
    # This is highly simplified. A real CHoCH requires identifying a clear
    # break of market structure.
    current_price = rates[-1]['close']
    if current_price > prev_session_high:
        logging.info(f"Liquidity sweep above previous high detected for {symbol}.")
        # Look for a bearish CHoCH
        # Simplified: if price breaks a recent low after sweeping the high
        recent_low = min(rates['low'][-20:])
        if current_price < recent_low:
            logging.info(f"Bearish CHoCH detected on {symbol}.")
            # 3. The Strike: Execute on Order Block mitigation
            # Placeholder: identify the last bullish candle before the sweep
            order_block_price = rates[-10]['high']
            stop_loss = order_block_price * 1.0005 # 5 pips above
            take_profit = current_price - (order_block_price - current_price) # 1:1 RR
            return 'SELL', stop_loss, take_profit
            
    elif current_price < prev_session_low:
        logging.info(f"Liquidity sweep below previous low detected for {symbol}.")
        # Look for a bullish CHoCH
        recent_high = max(rates['high'][-20:])
        if current_price > recent_high:
            logging.info(f"Bullish CHoCH detected on {symbol}.")
            # 3. The Strike: Execute on Order Block mitigation
            # Placeholder: identify the last bearish candle before the sweep
            order_block_price = rates[-10]['low']
            stop_loss = order_block_price * 0.9995 # 5 pips below
            take_profit = current_price + (current_price - order_block_price) # 1:1 RR
            return 'BUY', stop_loss, take_profit

    return None, None, None


def generate_weekly_report(start_balance):
    """Generates a weekly report of trading activity."""
    logging.info("Generating weekly report...")
    end_balance = mt5.account_info().balance
    profit_loss = end_balance - start_balance
    
    # Accuracy calculation would require tracking trades.
    # This is a placeholder.
    total_trades = 10 # dummy
    winning_trades = 7 # dummy
    accuracy = (winning_trades / total_trades) * 100 if total_trades > 0 else 0
    
    report = f"""
    --- Weekly Trading Report ---
    Date: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M")}
    
    Starting Balance: {start_balance:,.2f}
    Ending Balance:   {end_balance:,.2f}
    Profit/Loss:      {profit_loss:,.2f}
    
    Accuracy:         {accuracy:.2f}%
    Trades Placed:    {total_trades}
    
    New Compounding Level (Balance): {end_balance:,.2f}
    --- End of Report ---
    """
    
    with open("Weekly_Report.txt", "w") as f:
        f.write(report)
    logging.info("Weekly report generated.")


def main():
    """The main execution engine for the Forex Forge bot."""
    logging.info("--- Starting Forex Forge 2.0 ---")
    backup_project()

    if not mt5.initialize(login=MT5_LOGIN, password=MT5_PASSWORD, server=MT5_SERVER):
        logging.error(f"MT5 initialization failed. Error code: {mt5.last_error()}")
        return

    # --- Safety Sync: Account Type Check ---
    account_info = mt5.account_info()
    if not account_info:
        logging.error("Failed to get account info. Aborting.")
        mt5.shutdown()
        return

    # Assuming a 'micro' account has a contract size of 1000 for a major pair
    symbol_info = mt5.symbol_info(f"EURUSD{SYMBOL_SUFFIX}")
    if symbol_info and symbol_info.trade_contract_size != 1000:
        logging.critical("CRITICAL: Account is not a 'Micro' account. Contract size for EURUSDmicro is not 1000.")
        logging.critical("ABORTING TRADING TO PROTECT CAPITAL.")
        mt5.shutdown()
        return
    
    logging.info(f"Successfully connected to MT5. Account: {account_info.login}, Balance: {account_info.balance}")
    
    start_balance = account_info.balance
    is_paused = False
    pause_time = None
    last_news_check = 0
    last_report_day = datetime.datetime.now().weekday()
    
    symbols_to_trade = [f"EURUSD{SYMBOL_SUFFIX}", f"USDZAR{SYMBOL_SUFFIX}"]

    while True:
        try:
            # --- Auto-Reconnect Logic ---
            if mt5.terminal_state().connected is False:
                logging.warning("MT5 connection lost. Reconnecting...")
                if not mt5.initialize(login=MT5_LOGIN, password=MT5_PASSWORD, server=MT5_SERVER):
                    logging.error("Failed to reconnect to MT5. Retrying in 30 seconds.")
                    time.sleep(30)
                    continue
                logging.info("Reconnected to MT5.")

            # --- News Scanner ---
            if time.time() - last_news_check > 3600: # Every 60 minutes
                if news_scanner():
                    is_paused = True
                    pause_time = time.time()
                last_news_check = time.time()

            if is_paused and pause_time and (time.time() - pause_time > 24 * 3600):
                is_paused = False
                pause_time = None
                logging.info("Trading pause lifted.")

            if is_paused:
                logging.info("Trading is paused due to news.")
                time.sleep(60)
                continue

            # --- Trading Logic ---
            for symbol in symbols_to_trade:
                if not mt5.symbol_select(symbol, True):
                    logging.warning(f"Could not select {symbol}, skipping...")
                    continue
                
                trade_type, sl, tp = smc_strategy(symbol)
                
                if trade_type:
                    logging.info(f"SMC Signal found for {symbol}: {trade_type}")
                    balance = mt5.account_info().balance
                    
                    # Placeholder for stop loss pips
                    stop_loss_pips = 50 # This should be dynamically calculated
                    
                    lot_size = calculate_lot_size(balance, stop_loss_pips, symbol)
                    
                    if lot_size > 0:
                        logging.info(f"Placing {trade_type} order for {lot_size} lots of {symbol}")
                        
                        price = mt5.symbol_info_tick(symbol).ask if trade_type == 'BUY' else mt5.symbol_info_tick(symbol).bid
                        
                        request = {
                            "action": mt5.TRADE_ACTION_DEAL,
                            "symbol": symbol,
                            "volume": lot_size,
                            "type": mt5.ORDER_TYPE_BUY if trade_type == 'BUY' else mt.ORDER_TYPE_SELL,
                            "price": price,
                            "sl": sl,
                            "tp": tp,
                            "magic": 23400,
                            "comment": "ForexForge_SMC",
                            "type_time": mt5.ORDER_TIME_GTC,
                            "type_filling": mt5.ORDER_FILLING_IOC,
                        }
                        
                        result = mt5.order_send(request)
                        if result.retcode != mt5.TRADE_RETCODE_DONE:
                            logging.error(f"Order send failed, retcode={result.retcode}")
                        else:
                            logging.info(f"Order sent successfully, order #{result.order}")

            # --- Weekly Report ---
            current_day = datetime.datetime.now().weekday()
            now = datetime.datetime.now()
            # If it's Friday and past 23:58 and we haven't generated a report today
            if current_day == 4 and now.hour >= 23 and now.minute >= 59 and last_report_day != current_day:
                generate_weekly_report(start_balance)
                last_report_day = current_day # Mark report as generated
            elif current_day != 4:
                last_report_day = -1 # Reset on any other day

            time.sleep(10) # Main loop delay

        except Exception as e:
            logging.error(f"An error occurred in the main loop: {e}")
            time.sleep(30) # Wait before retrying after an error

if __name__ == "__main__":
    main()
