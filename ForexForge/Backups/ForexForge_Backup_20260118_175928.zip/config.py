# config.py (The Credentials Brain)

# --- MetaTrader 5 Credentials ---
# IMPORTANT: Replace with your actual account details
MT5_LOGIN = 309567916
MT5_PASSWORD = "Investor8!"
MT5_SERVER = "XMGlobal-MT5 6"

# --- Trading Parameters ---
# Append 'micro' to all symbols, e.g., EURUSD -> EURUSDmicro
SYMBOL_SUFFIX = 'micro'

# --- Risk Management ---
# Risk 1% of account balance per trade
RISK_PER_TRADE = 0.01
# Max 3% total loss for the day before pausing all trading
MAX_DAILY_LOSS = 0.03

# --- News Scanner ---
# Keywords that flag South African market volatility
ZAR_RED_FLAGS = ('SARB', 'MPC', 'Repo', 'Eskom', 'Grid', 'CPI', 'Inflation', 'unemployment')
